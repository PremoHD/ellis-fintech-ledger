# Ellis Fintech Ledger
This is a fully local ledger simulation system for testing ACH, card, and check flows.